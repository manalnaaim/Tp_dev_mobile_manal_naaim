// mathUtils.js
export const PI = 3.14;

export function carre(x) {
  return x * x;
}

// Export par défaut
export default function message() {
  console.log("📘 Module mathUtils chargé !");
}