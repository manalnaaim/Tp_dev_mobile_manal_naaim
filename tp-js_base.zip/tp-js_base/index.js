// index.js
import message, { PI, carre } from "./mathUtils.js";

message(); // 📘 Module mathUtils chargé !
console.log("PI =", PI);
console.log("Carré de 5 =", carre(5));

// Tu peux tester d'autres fonctions
console.log("Carré de 10 =", carre(10));
console.log("PI arrondi =", Math.round(PI));